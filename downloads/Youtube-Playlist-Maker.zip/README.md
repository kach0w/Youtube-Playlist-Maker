# Google Extension
<b>Working with Google Extensions</b>

Found a good framework to build my own extension (@T-L-H)

Here is what mine does: 

Creates a list of a youtuber's video with the urls for each accessible in the extension popup


# Plans:

Make list available in downloadable file

Publish to web store?
